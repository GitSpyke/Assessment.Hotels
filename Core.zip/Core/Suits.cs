﻿namespace Assessment.Hotels.Core
{
    public enum Suits
    {
        Family, Adult, Senior
    }
}